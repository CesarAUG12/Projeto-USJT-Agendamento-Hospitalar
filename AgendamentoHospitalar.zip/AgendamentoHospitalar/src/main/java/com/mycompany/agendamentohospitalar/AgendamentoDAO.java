package com.mycompany.agendamentohospitalar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AgendamentoDAO {

    public boolean existe(Usuario usuario)
            throws Exception {

        String sql = "SELECT * FROM "
                + "Usuario WHERE "
                + "nome = ? AND senha = ?";
        try (Connection conn
                = ConexaoBD.obtemConexao(); PreparedStatement ps
                = conn.prepareStatement(sql)) {
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenha());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void agendar(Consulta consulta) throws Exception {
        String sql = "INSERT INTO Agendamento(data_hora, id_paciente, id_medico, id_hospital, id_convenio, id_plano_de_saude, especialidade) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = ConexaoBD.obtemConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, consulta.getData_hora());
            ps.setInt(2, consulta.getId_paciente());
            ps.setInt(3, consulta.getId_medico());
            ps.setInt(4, consulta.getId_hospital());
            ps.setInt(5, consulta.getId_convenio());
            ps.setInt(6, consulta.getId_plano_saude());
            ps.setString(7, consulta.getId_especialidade());
            ps.execute();
        }
    }

    public void atualizar(Consulta consulta) throws Exception {
        String sql = "UPDATE Agendamento SET data_hora = ?, id_paciente = ?, id_medico = ?, id_hospital = ?, id_convenio = ?, id_plano_de_saude = ? ,especialidade = ?  WHERE id = ?";
        try (Connection conn = ConexaoBD.obtemConexao(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, consulta.getData_hora());
            ps.setInt(2, consulta.getId_paciente());
            ps.setInt(3, consulta.getId_medico());
            ps.setInt(4, consulta.getId_hospital());
            ps.setInt(5, consulta.getId_convenio());
            ps.setInt(6, consulta.getId_plano_saude());
            ps.setString(7, consulta.getId_especialidade());
             ps.setInt(8, consulta.getId_plano_saude());
            ps.execute();
        }
    }
    
     public void excluir (Consulta consulta) throws Exception{
        
        String sql = "DELETE FROM Agendamento Where id = ?";
        
        try(Connection conn = ConexaoBD.obtemConexao();PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, consulta.getId());
            ps.execute();
        }
    }
}

